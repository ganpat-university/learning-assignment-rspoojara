﻿using System;

namespace GenericsExample
{
    internal class Program
    {
        static void Main(string[] args)
        {
            MyGenericType<int> intVariable = new MyGenericType<int>();

            MyGenericType<string> stringVariable = new MyGenericType<string>();

            MyGenericType<Employee> employee = new MyGenericType<Employee>();

            employee.value = new Employee()
            {
                EmployeeID = 10,
                EmployeeName = "Sachin"
            };
        }
    }
}
