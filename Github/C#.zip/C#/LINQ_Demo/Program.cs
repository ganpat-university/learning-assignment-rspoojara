﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace LINQ_Demo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            List<Product> products = new List<Product>()
            {
                new Product { ProductID = 3, ProductName ="Third"},
                new Product { ProductID = 1, ProductName ="First"},
                new Product { ProductID = 4, ProductName ="Fourth"},
                new Product { ProductID = 2, ProductName ="Second"},
            };


            Console.WriteLine("List Of Products");
            Console.WriteLine("{0} {1,-20}", "ProductID", "ProductName");
            foreach (Product p in products)
            {
                Console.WriteLine("{0:000} {1,20}", p.ProductID,p.ProductName);
            }

            var query = from p in products
                         orderby p.ProductID ascending
                         select p;


            Console.WriteLine("List Of Products");
            Console.WriteLine("{0} {1,-20}", "ProductID", "ProductName");
            foreach (Product p in query)
            {
                Console.WriteLine("{0:000} {1,20}", p.ProductID, p.ProductName);
            }
        }
    }
}
