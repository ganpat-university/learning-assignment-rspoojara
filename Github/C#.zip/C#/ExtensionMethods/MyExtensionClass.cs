﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionMethods
{
    /// <summary>
    /// only one instrance of the class will be loaded in the application.
    /// 
    /// </summary>
    static class MyExtensionClass
    {
        //How to prepare an extension method:
        //1. The class is singleton.
        //2. Ensure that the object to be extended is the FIRST PARAMETER.
        //3. Ensure that the first parameter decorated with the this keyword.
        public static int Multiply(this Calculator objCalc, int a, int b)
        {
            return a * b;
        }
    }
}
