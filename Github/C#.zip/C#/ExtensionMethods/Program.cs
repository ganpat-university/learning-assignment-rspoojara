﻿using System;

namespace ExtensionMethods
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Calculator objCalc = new Calculator();
            int result = objCalc.Add(10,20);
            Console.WriteLine("Sum of 10 and 20 is : {0}",result);


            result = MyExtensionClass.Multiply(objCalc,20,30);

            Console.WriteLine(result);

            result = objCalc.Multiply(10,20);
        }
    }
}
