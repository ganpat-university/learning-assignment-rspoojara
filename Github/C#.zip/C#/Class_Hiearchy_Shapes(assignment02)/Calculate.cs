﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_Hiearchy_Shapes
{
    class Calculate
    {
        public float radius { get; private set; }
        
        public float length { get; private set; }
        public float bredth { get; private set; }
        
        public double side1 { get; private set; }
        public double side2 { get; private set; }
        public double base1 { get; private set; }
        public double heightoftriangle { get; private set; }
        
        public double side { get; private set; }
        
        
        MenuOption objCalc = new MenuOption();
        public void circleCalc()
        {
            Console.WriteLine("Enter the Radius:");
            radius= float.Parse(Console.ReadLine());
            Console.WriteLine("Perimeter of circle is: {0}",perimeter(radius));
            Console.WriteLine("Area of circle is: {0}",area(radius));
        }
        public void rectangleCalc()
        {
            Console.WriteLine("Enter the Length:");
            length = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Bredth:");
            bredth = float.Parse(Console.ReadLine());

            Console.WriteLine("Perimeter of Rectangle is: {0}",perimeter(length,bredth));
            Console.WriteLine("Area of Rectangle is: {0}", area(length, bredth));
        }
        public void triangleCalc()
        {
            Console.WriteLine("Enter the 1st side:");
            side1 = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter the base:");
            base1 = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter the 2nd side:");
            side2 = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter the height:");
            heightoftriangle = double.Parse(Console.ReadLine());

            Console.WriteLine("Perimeter of Rectangle is: {0}", perimeter(side1,base1,side2));
            Console.WriteLine("Area of Rectangle is: {0}", area(base1, heightoftriangle));
        }
        public void squareCalc()
        {
            Console.WriteLine("Enter the side:");
            side = double.Parse(Console.ReadLine());

            Console.WriteLine("Perimeter of Rectangle is: {0}", perimeter(side));
            Console.WriteLine("Area of Rectangle is: {0}", area(side));
        }

        // circle
        public float perimeter(float radius)
        {
            return 2 * 3.14f * radius;
        } 
        // rectangle
        public float perimeter(float length, float bredth)
        {
            return 2 * (length + bredth);
        }

        //square
        public double perimeter(double side)
        {
            return 4 * side;
        }

        //triangle
        public double perimeter(double side1, double base1, double side2)
        {
            return side1 + base1 + side2;
        }

        //square
        public double area(double side)
        {
            return side * side;
        }

        //circle
        public float area(float radius)
        {
            return 3.14f * radius * radius;
        }

        //reactangle
        public float area(float length, float bredth)
        {
            return length * bredth;
        }

        //triangle
        public double area(double base1,double height)
        {
            return height * base1 / 2;
        }
    }
}