﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_Hiearchy_Shapes
{
    class MenuOption
    {
        public int choice1 {get ; private set;}
        public void menuOption()
        {
            Console.WriteLine("----------Menu----------");
            Console.WriteLine("1. Circle");
            Console.WriteLine("2. Square");
            Console.WriteLine("3. Triangle");
            Console.WriteLine("4. Rectangle");
            Console.Write("Enter Your choice: ");
            choice1 = int.Parse(Console.ReadLine());
            Calculate objCalculate = new Calculate();
            switch (choice1)
            {
                case 1:
                    objCalculate.circleCalc();
                    break;
                case 2:
                    objCalculate.squareCalc();
                    break;
                case 3:
                    objCalculate.triangleCalc();
                    break;
                case 4:
                    objCalculate.rectangleCalc();
                    break;
                default:
                    Console.WriteLine("Please Enter the Valid Number!");
                    break;
            }
        }
    }
}
