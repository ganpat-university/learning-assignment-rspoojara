﻿using System;


namespace Class_Hiearchy_Shapes
{
    internal class Program
    {
        static void Main(string[] args)
        {
            MenuOption objCalc = new MenuOption();

            objCalc.menuOption();
        }
    }
}
