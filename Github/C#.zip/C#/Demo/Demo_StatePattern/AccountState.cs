﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StatePattern
{
    abstract class AccountState
    {
        protected BankAccount account;
        protected double balance;
        protected double lowerLimit;
        protected double upperLimit;

        public BankAccount Account
        {
            get { return account; }
            set { account = value; }
        }

        public double Balance
        {
            get { return balance; }
            set { balance = value; }
        }

        abstract public void Deposit(double amount);
        abstract public void Withdraw(double amount);
    }

    class GoldState : AccountState
    {
        public GoldState(AccountState state)
            : this(state.Balance, state.Account)
        {
        }

        public GoldState(double balance, BankAccount account)
        {
            base.balance = balance;
            base.account = account;
            base.upperLimit = 100000.0;
            base.lowerLimit = 25000.0;
        }

        public override void Deposit(double amount)
        {
            base.balance += amount;
            this.changeState();
        }

        public override void Withdraw(double amount)
        {
            base.balance -= amount;
            this.changeState();
        }

        private void changeState()
        {
            if (base.balance < base.lowerLimit)
            {
                base.account.State = new SilverState(this);
            }
            else if (base.balance > base.upperLimit)
            {
                base.account.State = new PlatinumState(this);
            }
        }
    }

    class SilverState : AccountState
    {
        public SilverState(AccountState state)
            : this(state.Balance, state.Account)
        {
        }

        public SilverState(double balance, BankAccount account)
        {
            base.balance = balance;
            base.account = account;
            base.upperLimit = 25000.0;
            base.lowerLimit = 0.0;
        }

        public override void Deposit(double amount)
        {
            this.balance += amount;
            changeState();
        }

        public override void Withdraw(double amount)
        {
            this.balance -= amount;
            changeState();
        }

        private void changeState()
        {
            if (base.balance > base.upperLimit)
            {
                base.account.State = new GoldState(base.balance, account);
            }
        }
    }

    class PlatinumState : AccountState
    {
        public PlatinumState(AccountState state)
            : this(state.Balance, state.Account)
        {
        }

        public PlatinumState(double balance, BankAccount account)
        {
            base.balance = balance;
            base.account = account;
            base.upperLimit = double.MaxValue;
            base.lowerLimit = 100000.0;
        }

        public override void Deposit(double amount)
        {
            base.balance += amount;
            changeState();
        }

        public override void Withdraw(double amount)
        {
            base.balance -= amount;
            changeState();
        }

        private void changeState()
        {
            if (base.balance < base.lowerLimit)
            {
                base.account.State = new GoldState(base.balance, account);
            }
        }

    }


}
