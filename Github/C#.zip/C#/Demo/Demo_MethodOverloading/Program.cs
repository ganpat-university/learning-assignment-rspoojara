﻿using System;

namespace Demo_MethodOverloading
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Demo obj = new Demo();

            obj.DoSomething(10); // overloaded method
            obj.DoSomething("hello world");
            obj.DoSomething(true);


            AnotherDemo obj2 = new AnotherDemo();
            obj2.DoSomething(10); // method called by boxing the parameter
            obj2.DoSomething("hello world");
            obj2.DoSomething(true);
            obj2.DoSomething(30L);


            int i = 10;
            bool b = true;
            object o = i;           // boxing int into the object - Implicitly 
            o = b;                  // boxing bool into the object
            int j = (int)o;        // unboxing - Explicitly

        }
    }
}
