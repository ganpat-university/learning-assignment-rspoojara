﻿using System;

namespace Constructor
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee("First Employee");
            Console.WriteLine(emp.Name);

            Demo02 demo2obj = new Demo02();
        }
    }
}
