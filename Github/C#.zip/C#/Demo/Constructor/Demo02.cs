﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructor.Demo02
{

    // C# Language Compiler will Add the Constructor if the developer does not define a constructor
    class DemoA
    {
    }

    class DemoB
    {
        // Default Constructor defined by the Developer (parameterless)
        public DemoB()
        {

        }
    }

    class DemoC
    {
        // Parameterized Constructor defined by the developer.
        public DemoC(int i)
        {

        }
    }

    class DemoD
    {
        // Default / parameterless constructor defined by the developer
        public DemoD()
        {

        }

        // Parameterized constructor defined by the developer
        public DemoD(int id)
        {

        }
    }
}
