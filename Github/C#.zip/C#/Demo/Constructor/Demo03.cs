﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructor.Demo03
{
    class Demo
    {
        static void Run()
        {
            MyDerivedClass obj = new MyDerivedClass(50);
        }
    }


    class MyBaseClass
    {
        public MyBaseClass()
        {
        }

        public MyBaseClass(int i)
        {
        }

    }

    class MyDerivedClass : MyBaseClass
    {

        public MyDerivedClass(int i) : base(10)
        {

        }

    }


}
