﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructor.Demo04
{
    class Person
    {
        // instance members
        public readonly int ID;
        public readonly string Name;

        // type member
        static private int counter;

        // Type Constructor
        static Person()
        {
            Person.counter = 0;
        }


        // Instance Constructor
        public Person(string name)
        {
            ID = ++Person.counter;
            Name = name;
        }
    }

    class Demo
    {
        static public void Run()
        {
            Person p1 = new Person("First Person");         // instance constructor is called here.
            Person p2 = new Person("Second Person");

            Console.WriteLine("{0} {1}", p1.ID, p1.Name);
            Console.WriteLine("{0} {1}", p2.ID, p2.Name);
        }
    }
}
