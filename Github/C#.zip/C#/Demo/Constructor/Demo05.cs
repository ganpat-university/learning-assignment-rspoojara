﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructor.Demo05
{
    class A
    {
        static A()
        {

        }

        public A()
        {

        }

    }

    class B : A
    {
        static B()
        {

        }

        public A()
        {

        }
    }
}
